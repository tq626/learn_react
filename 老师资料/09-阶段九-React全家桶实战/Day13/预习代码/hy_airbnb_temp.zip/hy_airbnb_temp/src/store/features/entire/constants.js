export const CHANGE_CURRENT_PAGE = "entire/change_current_page"
export const CHANGE_TOTAL_COUNT = "entire/change_total_count"
export const CHANGE_ROOM_LIST = "entire/change_room_list"
export const CHANGE_LOADING = 'entire/loading'
