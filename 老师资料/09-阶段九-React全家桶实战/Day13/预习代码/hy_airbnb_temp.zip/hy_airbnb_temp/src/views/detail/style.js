import styled from "styled-components";

export const DetailWrapper = styled.div`
  .demo01 {
    width: 100px;

    button {
      margin: 0 8px;
    }
  }
`