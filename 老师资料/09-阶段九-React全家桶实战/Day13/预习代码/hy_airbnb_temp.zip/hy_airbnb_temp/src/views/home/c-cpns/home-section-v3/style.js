import styled from "styled-components";

export const SectionV3Wrapper = styled.div`
  margin-top: 30px;

  .room-list {
    margin: 0 -8px;
  }
`