import styled from "styled-components";

export const LongForWrapper = styled.div`
  margin-top: 30px;
  
  .longfor-list {
    margin: 0 -8px;
  }
`