import styled from "styled-components";

export const SectionV3Wrapper = styled.div`
  .room-list {
    margin: 0 -8px;
  }
`