import React, { memo } from 'react'

const Entire = memo((props) => {
  return (
    <div>Entire</div>
  )
})

Entire.propTypes = {}

export default Entire