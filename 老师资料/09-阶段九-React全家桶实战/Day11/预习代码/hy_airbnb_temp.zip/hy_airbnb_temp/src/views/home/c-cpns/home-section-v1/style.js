import styled from "styled-components";

export const SectionV1Wrapper = styled.div`
  margin-top: 36px;
`